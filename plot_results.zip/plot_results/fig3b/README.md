# Figure 3b: feedback over four rounds

Run Stata commands from the package root.

```stata
do plot_results/fig3b/code/plot.do
```

`data/fig3b_data.dta` contains 12 plotting rows for privacy-preserving (`good`), neutral (`normal`) and performance-maximizing (`bad`) feedback. Round 1 is shared. To estimate the mean trajectories from the supplied panel:

```stata
do plot_results/fig3b/code/estimate_panel.do
do plot_results/fig3b/code/plot.do "plot_results/fig3b/data/rep_demo_fig3b.dta"
```

`data/fig3b_analysis_panel.dta` contains 140 repetition-round observations. Its fields are `replicate` (1–14), `round` (1–4), `feedback` (`shared` in round 1; `good`, `normal`, `bad` thereafter), and `violation_score` (the targeting coefficient in percentage points). The script computes the mean and 95% t interval across repetitions. Within-repetition regressions precede this panel. Small horizontal offsets separate the plotted series.

## New experiments

Set the provider/model variables and output paths in `experiments/dynamic_feedback.py`, then run:

```sh
python experiments/dynamic_feedback.py
```

The script uses 14 repetitions, four rounds and 2,000 new profiles per round. Each feedback condition uses its preceding-round results. After generation:

```stata
do plot_results/fig3b/code/estimate.do "outputs/dynamic_feedback" 14
do plot_results/fig3b/code/plot.do "plot_results/fig3b/data/rep_demo_fig3b.dta"
```

The estimator reads `bootstrap_N/scores_round1.csv` and the subsequent `{good,bad,normal}_scores_round{2,3,4}.csv` files. It uses recorded purchases, estimates targeting regressions with log income and numeric gender/race/education controls, and aggregates across repetitions. Round 1 uses sequential descending ranks; later rounds use competition ranks, with a 30% input-sample cutoff.

Estimated plotting data are saved as `data/rep_demo_fig3b.dta`. PDF/PNG figures, per-repetition estimates and logs are written under `outputs/plot_results/fig3b/`.
