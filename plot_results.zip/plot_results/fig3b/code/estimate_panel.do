* Figure 3b: archived repetition-round scores -> mean and t CI -> plot data.
* The individual-level regressions are already evaluated in this final panel.
version 17.0
clear all
set more off
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3b"
capture log close fig3b_panel
log using "outputs/plot_results/fig3b/estimate_panel.log", text replace name(fig3b_panel)

use "plot_results/fig3b/data/fig3b_analysis_panel.dta", clear
isid replicate round feedback
assert inrange(replicate,1,14) & inrange(round,1,4)
assert feedback=="shared" if round==1
assert inlist(feedback,"good","normal","bad") if round>1
assert !missing(violation_score)
by round feedback, sort: assert _N==14
tempfile panel estimates
save `panel'
tempname results
postfile `results' str8 sample double round coefficient cilb ciub using `estimates', replace

* First-round observations are shared, and enter each plotted series once.
foreach feedback in good normal bad {
    forvalues round=1/4 {
        use `panel', clear
        if `round'==1 keep if round==1
        else keep if round==`round' & feedback=="`feedback'"
        ci means violation_score, level(95)
        post `results' ("`feedback'") (`round') (r(mean)) (r(lb)) (r(ub))
    }
}
postclose `results'

* Original horizontal offsets distinguish the three series visually.
use `estimates', clear
replace round=round-0.1 if round!=1 & sample=="good"
replace round=round+0.1 if round!=1 & sample=="bad"
sort sample round
save "plot_results/fig3b/data/rep_demo_fig3b.dta", replace
log close fig3b_panel
