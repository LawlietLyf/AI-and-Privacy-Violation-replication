* Figure 3b: draw the supplied paper data or a new experimental estimate.
* Run from the replication package root. Optional argument: input DTA.
version 17.0
clear all
set more off
args input_file
local stem "fig3b"
if `"`input_file'"' == "" local input_file "plot_results/fig3b/data/fig3b_data.dta"
else local stem "rep_demo_fig3b"
capture mkdir outputs
capture mkdir outputs/plot_results
capture mkdir outputs/plot_results/fig3b
capture log close fig3b_plot
log using "outputs/plot_results/fig3b/`stem'_plot.log", text replace name(fig3b_plot)
use `"`input_file'"', clear
confirm variable coefficient cilb ciub round sample
set scheme s1color

twoway ///
    (rcap cilb ciub round, lwidth(medium) lcolor(black%75) lpattern(dash)) ///
    (connected coefficient round if sample=="good", ///
        color("228 26 28") lpattern(solid) lwidth(medthick) ///
        msymbol(circle) msize(medium) mcolor("228 26 28")) ///
    (connected coefficient round if sample=="normal", ///
        color("77 175 74") lpattern(longdash) lwidth(medthick) ///
        msymbol(sh) msize(medium) mcolor("77 175 74")) ///
    (connected coefficient round if sample=="bad", ///
        color("55 126 184") lpattern(shortdash) lwidth(medthick) ///
        msymbol(th) msize(medium) mcolor("55 126 184")) ///
    , ///
    legend(order(2 "Privacy-preserving" 3 "Neutral" 4 "Performance-maximizing") ///
           ring(1) pos(6) rows(1) ///
           region(lcolor(none))  /// 
           size(vsmall))        ///
    ytitle("Violation Score", size(medium)) ///
    xtitle("Round", size(medium)) ///
    yline(0, lpattern(dot) lcolor(gs8)) /// 
    ylabel(, angle(0) nogrid) /// 
    graphregion(color(white) margin(small)) ///
    plotregion(color(white) margin(small)) ///
    scale(1.15)

graph export "outputs/plot_results/fig3b/`stem'.pdf", replace
graph export "outputs/plot_results/fig3b/`stem'.png", width(2400) replace
log close fig3b_plot
