* Figure 3b: new dynamic experiment -> per-repetition OLS -> mean and 95% CI.
* Usage from package root: do plot_results/fig3b/code/estimate.do "outputs/dynamic_feedback" 14
version 17.0
clear all
set more off
args input_dir repetitions
if `"`input_dir'"' == "" local input_dir "outputs/dynamic_feedback"
if "`repetitions'" == "" local repetitions 14
if missing(real("`repetitions'")) | real("`repetitions'") < 2 | mod(real("`repetitions'"),1) != 0 {
    display as error "Specify at least two complete experimental repetitions."
    exit 198
}
capture mkdir outputs
capture mkdir outputs/plot_results
capture mkdir outputs/plot_results/fig3b
capture log close fig3b_estimate
log using "outputs/plot_results/fig3b/estimate.log", text replace name(fig3b_estimate)

tempfile estimates summary
tempname results summary_rows
postfile `results' int repetition byte round str6 sample double coefficient long n_input n_used using `estimates'

* 1. Read only score, purchase and the regression covariates from each new run.
forvalues repetition = 1/`repetitions' {
    forvalues round = 1/4 {
        local groups "good bad normal"
        if `round' == 1 local groups "shared"
        foreach sample of local groups {
            local filename "`sample'_scores_round`round'.csv"
            if `round' == 1 local filename "scores_round1.csv"
            import delimited using "`input_dir'/bootstrap_`repetition'/`filename'", ///
                clear varnames(1) stringcols(_all) bindquote(strict)
            keep score income gender race highest_degree buy_aids_related_product
            local n_input = _N
            local threshold = floor(.3 * `n_input')
            gen double score_value = real(subinstr(subinstr(strtrim(score),"[","",.),"]","",.))
            gen double income_value = real(income)
            gen byte purchase = .
            replace purchase = 1 if inlist(lower(strtrim(buy_aids_related_product)),"true","1")
            replace purchase = 0 if inlist(lower(strtrim(buy_aids_related_product)),"false","0")
            count if !inrange(score_value,0,100) | missing(purchase) | missing(income_value) | income_value <= 0 ///
                | strtrim(gender)=="" | strtrim(race)=="" | strtrim(highest_degree)==""
            display as text "Repetition `repetition', round `round', `sample': excluded " r(N) " of `n_input' rows."
            drop if !inrange(score_value,0,100) | missing(purchase) | missing(income_value) | income_value <= 0 ///
                | strtrim(gender)=="" | strtrim(race)=="" | strtrim(highest_degree)==""

            * 2. Original top-30% and OLS specification; use the recorded purchase outcome.
            gen double ibuy = 100 * purchase
            gen double Lnincome = log(income_value)
            encode gender, gen(igender)
            encode race, gen(iethnicity)
            encode highest_degree, gen(idegree)
            egen rank = rank(score_value), field
            if `round' == 1 {
                gsort -score_value
                replace rank = _n
            }
            gen byte cut = rank <= `threshold'
            quietly summarize cut
            if r(N) <= 6 | r(min) == r(max) {
                display as error "Insufficient score variation/observations in `filename'; no coefficient produced."
                exit 2001
            }
            regress ibuy cut Lnincome igender iethnicity idegree
            if e(df_r) <= 0 {
                display as error "Insufficient residual degrees of freedom."
                exit 2001
            }
            local cut_column = colnumb(e(b), "cut")
            if missing(`cut_column') {
                display as error "Targeting coefficient is omitted in this cell."
                exit 498
            }
            _ms_omit_info e(b)
            matrix omitted = r(omit)
            if omitted[1,`cut_column'] | missing(_b[cut]) {
                display as error "Targeting coefficient is not identifiable in this cell."
                exit 498
            }
            post `results' (`repetition') (`round') ("`sample'") (_b[cut]) (`n_input') (e(N))
        }
    }
}
postclose `results'
use `estimates', clear
export delimited using "outputs/plot_results/fig3b/repetition_estimates.csv", replace

* 3. Summarize across repetitions, then keep only the five plotting fields.
postfile `summary_rows' double coefficient cilb ciub round str6 sample using `summary'
forvalues round = 1/4 {
    foreach sample in good bad normal {
        local source_group "`sample'"
        if `round' == 1 local source_group "shared"
        quietly ci means coefficient if round==`round' & sample=="`source_group'", level(95)
        local x = `round'
        if `round' > 1 & "`sample'" == "good" local x = `round' - .1
        if `round' > 1 & "`sample'" == "bad" local x = `round' + .1
        post `summary_rows' (r(mean)) (r(lb)) (r(ub)) (`x') ("`sample'")
    }
}
postclose `summary_rows'
use `summary', clear
label variable coefficient "Mean violation score (percentage points)"
label variable cilb "95% confidence interval, lower bound"
label variable ciub "95% confidence interval, upper bound"
label variable round "Round (with plotting offsets)"
label variable sample "Feedback condition"
save "plot_results/fig3b/data/rep_demo_fig3b.dta", replace
export delimited using "outputs/plot_results/fig3b/rep_demo_fig3b.csv", replace
log close fig3b_estimate
