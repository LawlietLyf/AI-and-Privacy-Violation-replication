# Single-model analysis demonstration

Run from the package root in Stata:

```stata
do plot_results/demo/code/run_demo.do
```

This estimates and plots one baseline coefficient from the supplied Qwen sample, using the Figure 3c estimator. It requires no API access.

`data/processing_sample.csv` contains 2,000 observations and seven fields:

| Field | Definition |
|---|---|
| `user_id` | Row identifier, starting at 0 |
| `income` | Annual income in US dollars |
| `gender`, `race`, `highest_degree` | Synthetic demographic characteristics |
| `purchase` | Recorded purchase outcome, 0 or 1 |
| `score` | Model prediction on a 0–100 scale |

The analysis regresses purchase (multiplied by 100) on a top-30% targeting indicator, log income and the original numeric demographic encodings. Expected coefficient: **47.647003**; 95% confidence interval: **43.434422–51.859581**; regression observations: **2,000**.

The plotting data are saved as `plot_results/fig3c/data/rep_demo_fig3c.dta`. The figure and log are under `outputs/plot_results/fig3c/`, with the `rep_demo_fig3c` figure prefix.

To use the same sample with the Figure 2 processing estimator:

```stata
do plot_results/demo/code/run_fig2_demo.do
```

This creates one processing estimate with the same expected coefficient and interval, saved as `plot_results/fig2/data/rep_demo_fig2.dta`, plus a figure under `outputs/plot_results/fig2/`. The accompanying `code/runs.csv` and `code/fig2_runs.csv` identify the sample for the two commands.
