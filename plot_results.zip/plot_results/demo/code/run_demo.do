* Route 3: one-model coefficient estimation, no API calls.
* Run from the replication package root.
version 17.0
clear all
set more off

do plot_results/fig3c/code/estimate.do "plot_results/demo/code/runs.csv"
do plot_results/fig3c/code/plot.do "plot_results/fig3c/data/rep_demo_fig3c.dta"
