* Figure 2 processing demo: one model, no raw experiment archive or API calls.
version 17.0
clear all
set more off
do plot_results/fig2/code/estimate.do "plot_results/demo/code/fig2_runs.csv"
do plot_results/fig2/code/plot.do "plot_results/fig2/data/rep_demo_fig2.dta"
