# Extended Data Figure 2: Nonsense condition

Run from the package root in Stata 17+, with `grstyle` installed.

## Paper figure

```stata
do plot_results/ed2/code/plot.do
```

`data/ED2_data.dta` contains 34 plotting rows: baseline and Nonsense estimates for 17 models. `violation_score` is the coefficient, `cilb` and `ciub` are the 95% confidence limits, and `group_pos` places the bars. `test="Nonsense"` identifies the Nonsense condition; blank `test` identifies the baseline. Output: `outputs/plot_results/ed2/ed2.pdf` and `.png`.

## Estimate from the supplied panel

```stata
do plot_results/ed2/code/estimate_panel.do
do plot_results/ed2/code/plot.do "plot_results/ed2/data/rep_demo_ed2.dta"
```

`data/ed2_analysis_panel.dta` contains 33,310 observations for the 17 Nonsense-condition models. Fields are `model`, `obs_id`, `model_order` (0–16), `ibuy` (purchase, 0 or 100), `cut` (targeting indicator), `Lnincome`, `igender`, `iethnicity` and `idegree`. Demographic codes are 1 female/2 male, 1 black/2 white, and 1 bachelor/2 doctor/3 high school/4 master.

For each model the script runs `reg ibuy cut Lnincome igender iethnicity idegree`, retaining the `cut` coefficient and conventional 95% OLS t interval. The final outcomes and selection of 600 observations per model are saved in the panel.

The resulting `data/rep_demo_ed2.dta` combines the fitted Nonsense coefficients with the supplied baseline reference rows. Its PDF/PNG figures and estimation log are written under `outputs/plot_results/ed2/`, using the `rep_demo_ed2` prefix for the figures.
