* ED2: final Nonsense-condition panel -> targeting coefficients.
* Baseline reference bars come from the supplied paper plotting data.
version 17.0
clear all
set more off
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/ed2"
capture log close ed2_panel
log using "outputs/plot_results/ed2/estimate_panel.log", text replace name(ed2_panel)

use "plot_results/ed2/data/ed2_analysis_panel.dta", clear
isid model obs_id
assert inlist(ibuy,0,100) & inlist(cut,0,1)
assert !missing(Lnincome,igender,iethnicity,idegree,model_order)
tempfile panel estimates
save `panel'
levelsof model, local(models)
tempname results
postfile `results' str64 model double violation_score double cilb double ciub double group_pos using `estimates', replace

foreach model of local models {
    use `panel', clear
    keep if model=="`model'"
    local pos=2*model_order[1]
    * Preserve the original numeric controls and conventional OLS interval.
    reg ibuy cut Lnincome igender iethnicity idegree
    matrix T=r(table)
    post `results' ("`model'") (T[1,1]) (T[5,1]) (T[6,1]) (`pos')
}
postclose `results'

use "plot_results/ed2/data/ED2_data.dta", clear
keep if test!="Nonsense"
replace model=strtrim(model)
recast double violation_score cilb ciub
append using `estimates'
replace test="Nonsense" if missing(test) & mod(group_pos,2)==0
replace privacy_test="Data Processing"
isid model test, missok
sort group_pos
save "plot_results/ed2/data/rep_demo_ed2.dta", replace
log close ed2_panel
