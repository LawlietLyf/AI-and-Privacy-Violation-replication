* Re-estimate supported paper panels from the distributed final analysis data.
* Run from the replication package root. All generated files use rep_demo_*.
* Figure 2 has a separate single-model demo. ED1 and Fig. 4 retain their entries.
version 17.0
clear all
set more off
foreach panel in fig3a fig3b fig3c ed2 ed3 {
    do plot_results/`panel'/code/estimate_panel.do
    do plot_results/`panel'/code/plot.do "plot_results/`panel'/data/rep_demo_`panel'.dta"
}
