# Figure 3c: baseline and tuned-model inference

Run Stata commands from the package root.

```stata
do plot_results/fig3c/code/plot.do
```

`data/fig3c_data.dta` contains the four paper estimates. To estimate them from the supplied individual-level panel:

```stata
do plot_results/fig3c/code/estimate_panel.do
do plot_results/fig3c/code/plot.do "plot_results/fig3c/data/rep_demo_fig3c.dta"
```

`data/fig3c_analysis_panel.dta` has 7,996 observations across `raw`, `HH_tuned`, `sft_tuned` and `GDPR_tuning`. Its fields are:

| Field | Meaning |
|---|---|
| `experiment`, `obs_id` | Condition and source observation number |
| `ibuy`, `cut` | Purchase outcome (0 or 100) and final targeting indicator (0 or 1) |
| `Lnincome` | Log income |
| `igender` | 1 female; 2 male |
| `iethnicity` | 1 black; 2 white |
| `idegree` | 1 bachelor; 2 doctor; 3 high school; 4 master |

For each condition, the original regression is `reg ibuy cut Lnincome igender iethnicity idegree`, with conventional OLS standard errors and 95% t intervals. The numeric demographic encodings are retained. The supplied panel includes the final purchase outcome and targeting indicator.

## New inference results

Run the baseline with `experiments/information_processing.py`. For each tuned condition, configure its deployed model and distinct `CONFIG['input_dir']` and `CONFIG['save_dir']` in `experiments/processing_tuned.py`, then run that script. Each tuned output is named `scores_sft_tuning.csv` in its condition directory.

Fill `config/runs.csv` with `condition`, `input_csv` and `model_id`, using the actual saved files and deployments. Paths are relative to the package root.

```stata
do plot_results/fig3c/code/estimate.do "plot_results/fig3c/config/runs.csv"
do plot_results/fig3c/code/plot.do "plot_results/fig3c/data/rep_demo_fig3c.dta"
```

The estimator accepts the baseline `purchase` field or the tuned `buy_AIDS_related_product` field, scores on the 0–100 scale, income, gender, race and education. It constructs the top-30% indicator using descending competition rank and the initial sample size (cutoff 600 for 2,000 observations), then runs the regression above. Sample counts are recorded in the log.

Outputs are `data/rep_demo_fig3c.dta` and PDF/PNG figures under `outputs/plot_results/fig3c/`. This workflow performs inference with deployed tuned models. The [single-model demo](../demo/README.md) illustrates the same analysis using a supplied baseline sample.
