* Run from the replication package root. Default: draw the submitted paper data.
* Optional argument: a .dta created by code/estimate.do; draw available conditions only.
version 17.0
args input_dta
set more off
local output_name "rep_demo_fig3c"
if "`input_dta'"=="" {
    local input_dta "plot_results/fig3c/data/fig3c_data.dta"
    local output_name "fig3c"
}
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3c"
use "`input_dta'", clear

local positions ""
foreach condition in raw HH_tuned sft_tuned GDPR_tuning {
    quietly count if experiment=="`condition'"
    if r(N)>0 {
        if "`condition'"=="raw" local positions `"`positions' -.25 "Baseline""'
        if "`condition'"=="HH_tuned" local positions `"`positions' 1.75 "HH""'
        if "`condition'"=="sft_tuned" local positions `"`positions' 3.75 "Counterfact""'
        if "`condition'"=="GDPR_tuning" local positions `"`positions' 5.75 "Knowledge""'
    }
}
set scheme s1color

* Keep the single-model demonstration bar readable on its own.
local single_condition_options ""
local ylabels "ylabel(, angle(0))"
if _N==1 {
    local left=order[1]-1
    local right=order[1]+1
    local single_condition_options "xscale(range(`left' `right')) yscale(range(0))"
    local bottom=min(0,floor(cilb[1]/10)*10)
    local top=max(10,ceil(ciub[1]/10)*10)
    local ylabels "ylabel(`bottom'(10)`top', angle(0))"
}

* graphing
twoway (bar coefficient order  if  experiment=="raw",  color("77 175 74" ) barwidth(0.7) lcolor(gs8) lwidth(0.3)) ///
		(bar coefficient order  if  experiment=="HH_tuned" ,  color("255 127 0") barwidth(0.7) lcolor(gs8) lwidth(0.3)) ///
		(bar coefficient order  if  experiment=="sft_tuned" , color("55 126 184")   barwidth(0.7) lcolor(gs8) lwidth(0.3)) ///
		(bar coefficient order  if  experiment=="GDPR_tuning" , color("228 26 28")  barwidth(0.7) lcolor(gs8) lwidth(0.3)) ///
		(rcap cilb ciub order,  lwidth(medium) lcolor(black%75) lpattern(dash)), ///
             xlabel(`positions', labsize(2.8) noticks angle(0)) ///
             `ylabels' ///
             `single_condition_options' ///
             ytitle("Violation Score",size(*1.2)) ///
             xtitle("") ///
			     graphregion(color(white) margin(small)) ///
    plotregion(color(white) margin(small)) ///
             legend(off) ///
			 scale(1.2)

graph export "outputs/plot_results/fig3c/`output_name'.pdf", replace
graph export "outputs/plot_results/fig3c/`output_name'.png", width(1800) replace
