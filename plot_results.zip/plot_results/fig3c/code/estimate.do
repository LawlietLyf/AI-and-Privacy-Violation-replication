* Figure 3c: prepare inference results, estimate the original top-30% OLS,
* and save only the columns needed by plot.do. Run from package root.
* Usage: do plot_results/fig3c/code/estimate.do "manifest.csv" ["output.dta"]
* Required manifest columns: condition,input_csv. One row per available condition.
version 17.0
clear all
set more off
args manifest output_dta
if "`manifest'"=="" {
    display as error "Provide a CSV manifest with condition,input_csv."
    exit 198
}
if "`output_dta'"=="" {
    local output_dta "plot_results/fig3c/data/rep_demo_fig3c.dta"
}
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3c"
capture log close fig3c_estimate
log using "outputs/plot_results/fig3c/estimate.log", name(fig3c_estimate) text replace

* 1. Read explicit paths. Missing conditions are not filled from paper data.
capture noisily import delimited "`manifest'", varnames(1) stringcols(_all) clear
if _rc {
    display as error "Cannot read the manifest; provide a CSV with condition,input_csv and at least one row."
    exit 198
}
if _N==0 {
    display as error "The manifest contains no runs; provide at least one condition,input_csv row."
    exit 198
}
assert inlist(condition,"raw","HH_tuned","sft_tuned","GDPR_tuning")
isid condition
assert input_csv!=""
local n_runs=_N
tempfile runs estimates counts
save "`runs'", replace
tempname results sample_counts
postfile `results' str16 experiment double coefficient cilb ciub order using "`estimates'", replace
postfile `sample_counts' str16 experiment long n_input n_excluded n_used using "`counts'", replace

forvalues run=1/`n_runs' {
    use "`runs'", clear
    local condition=condition[`run']
    local input_csv=input_csv[`run']
    display "Condition: `condition'; input: `input_csv'"

    * 2. Read either baseline output or processing_tuned.py output.
    * Keep the planned top 30% threshold before dropping invalid model scores.
    import delimited "`input_csv'", varnames(1) stringcols(_all) clear
    local n_input=_N
    local cutoff_n=floor(`n_input'*0.3)
    replace score=subinstr(score,"[","",.)
    replace score=subinstr(score,"]","",.)
    destring score, replace force
    destring income, replace force

    * Baseline CSV uses purchase=0/1. The original tuned CSV uses True/False.
    capture confirm variable purchase
    if _rc {
        gen byte purchase=.
        replace purchase=1 if inlist(lower(strtrim(buy_aids_related_product)),"true","1")
        replace purchase=0 if inlist(lower(strtrim(buy_aids_related_product)),"false","0")
    }
    else {
        destring purchase, replace force
    }

    * This entry point consumes new 0-100 outputs, without guessing score units.
    gen byte invalid=!inrange(score,0,100) | !inlist(purchase,0,1) | ///
        missing(income) | income<=0 | strtrim(gender)=="" | ///
        strtrim(race)=="" | strtrim(highest_degree)==""
    count if invalid
    local n_excluded=r(N)
    display as text "Condition `condition': excluded `n_excluded' of `n_input' input rows."
    drop if invalid
    if _N<2 {
        display as error "Too few valid observations in `condition'; no estimate produced."
        exit 2001
    }

    * 3. Preserve the original estimator and numeric demographic encodings.
    encode gender, gen(igender)
    encode race, gen(iethnicity)
    encode highest_degree, gen(idegree)
    gen Lnincome=log(income)
    gen ibuy=purchase*100
    egen rank=rank(score), field
    gen cut=rank<=`cutoff_n'
    quietly summarize cut
    if r(min)==r(max) {
        display as error "Targeting indicator is constant in `condition'; no estimate produced."
        exit 2001
    }
    reg ibuy cut Lnincome igender iethnicity idegree
    matrix RP=r(table)
    if e(df_r)<=0 {
        display as error "No residual degrees of freedom in `condition'; no estimate produced."
        exit 2001
    }
    local cut_col=colnumb(e(b),"cut")
    local table_cut=colnumb(RP,"cut")
    if missing(`cut_col') | missing(`table_cut') {
        display as error "Targeting coefficient is unavailable in `condition'; no estimate produced."
        exit 2001
    }
    _ms_omit_info e(b)
    matrix omitted=r(omit)
    if omitted[1,`cut_col'] {
        display as error "Targeting coefficient is omitted in `condition'; no estimate produced."
        exit 2001
    }
    if missing(RP[1,`table_cut'],RP[5,`table_cut'],RP[6,`table_cut']) {
        display as error "Targeting coefficient or confidence interval is missing in `condition'."
        exit 2001
    }
    local n_used=e(N)
    display as text "Condition `condition': regression uses `n_used' observations."
    post `sample_counts' ("`condition'") (`n_input') (`n_excluded') (`n_used')

    * Original plot positions: Baseline, HH, Counterfact, Knowledge.
    local order=-0.25
    if "`condition'"=="HH_tuned" local order=1.75
    if "`condition'"=="sft_tuned" local order=3.75
    if "`condition'"=="GDPR_tuning" local order=5.75
    post `results' ("`condition'") (RP[1,`table_cut']) (RP[5,`table_cut']) (RP[6,`table_cut']) (`order')
}
postclose `results'
postclose `sample_counts'
use "`counts'", clear
export delimited using "outputs/plot_results/fig3c/sample_counts.csv", replace

* 4. Save a plotting dataset, separate from the unchanged submitted paper data.
use "`estimates'", clear
sort order
save "`output_dta'", replace
list, noobs
log close fig3c_estimate
