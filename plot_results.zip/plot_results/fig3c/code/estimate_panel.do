* Figure 3c: final individual-level panel -> original OLS -> plotting data.
version 17.0
clear all
set more off
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3c"
capture log close fig3c_panel
log using "outputs/plot_results/fig3c/estimate_panel.log", text replace name(fig3c_panel)

use "plot_results/fig3c/data/fig3c_analysis_panel.dta", clear
isid experiment obs_id
assert inlist(ibuy,0,100) & inlist(cut,0,1)
assert !missing(Lnincome,igender,iethnicity,idegree)
tempfile panel estimates
save `panel'
tempname results
postfile `results' str16 experiment double coefficient cilb ciub order using `estimates', replace

* cut, purchase outcomes and numeric control encodings are already fixed.
* Keep the original numeric slopes and conventional OLS standard errors.
local pos=-0.25
foreach condition in raw HH_tuned sft_tuned GDPR_tuning {
    use `panel', clear
    keep if experiment=="`condition'"
    reg ibuy cut Lnincome igender iethnicity idegree
    matrix T=r(table)
    post `results' ("`condition'") (T[1,1]) (T[5,1]) (T[6,1]) (`pos')
    local pos=`pos'+2
}
postclose `results'
use `estimates', clear
sort order
save "plot_results/fig3c/data/rep_demo_fig3c.dta", replace
log close fig3c_panel
