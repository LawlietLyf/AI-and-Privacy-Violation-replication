* Route 2: reproduce the paper figures from supplied plotting and empirical datasets.
* Open Stata in the replication package root. No model API is called.
version 17.0
clear all
set more off

do plot_results/fig2/code/plot.do
do plot_results/fig3a/code/plot.do
do plot_results/fig3b/code/plot.do
do plot_results/fig3c/code/plot.do
do plot_results/fig4/code/run.do
do plot_results/plot_extended_data.do
