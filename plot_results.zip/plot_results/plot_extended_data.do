* Draw Extended Data Figures 1a, 2 and 3 from the supplied data.
* Open Stata in the replication package root. No model API is called.
version 17.0
clear all
set more off
do plot_results/ed1/code/plot.do
do plot_results/ed2/code/plot.do
do plot_results/ed3/code/plot.do
