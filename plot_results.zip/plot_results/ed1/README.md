# Extended Data Figure 1a: privacy preferences

Run from the package root in Stata 17+:

```stata
do plot_results/ed1/code/plot.do
```

The default input is `data/results_rand.csv`: 2,000 independent responses with uniformly drawn bonus and penalty amounts (1,524 Yes; 476 No). The additional `data/results_randn.csv` contains 2,000 responses with lognormal incentives (1,949 Yes; 51 No):

```stata
do plot_results/ed1/code/plot.do "plot_results/ed1/data/results_randn.csv"
```

Both files have three fields: `bonus` (reward in dollars), `punish` (penalty in dollars), and `score` (the answer and explanation). The plot uses the leading Yes/No answer: red denotes Yes, blue denotes No, and the green dashed line denotes equal bonus and penalty. The axes cover the observed incentive range. Parsing status is recorded in an output CSV.

Outputs are PDF, PNG, parsed answers and a log under `outputs/plot_results/ed1/`. The default prefix is `ed1a`; the additional variant uses `ed1a_randn`. Panel 1b is the interface illustration in the submitted PDF.

## New model responses

Configure the provider and model as described in the [main README](../../README.md), then run:

```sh
python experiments/privacy_preference.py
```

The script generates 2,000 independent queries at temperature 0. Bonus and penalty are independent uniform integers from 100 through 9,999. Output is `outputs/privacy_preference/results.csv` by default. Plot it with:

```stata
do plot_results/ed1/code/plot.do "outputs/privacy_preference/results.csv"
```

New-result figures use the `rep_demo_ed1a` prefix.
