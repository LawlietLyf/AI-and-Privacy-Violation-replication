# Figure 3a: policy interventions

Run Stata commands from the package root.

## Paper figure and supplied panel

```stata
do plot_results/fig3a/code/plot.do
```

`data/fig3a_data.dta` contains 24 estimates: four policies for GPT-4o, Qwen Turbo, DeepSeek R1 671B, Gemini 2.0 Flash, Claude 3.5 Haiku and Llama 3.1 70B. To estimate from the supplied agent-period panel:

```stata
do plot_results/fig3a/code/estimate_panel.do
do plot_results/fig3a/code/plot.do "plot_results/fig3a/data/rep_demo_fig3a.dta"
```

`data/fig3a_analysis_panel.dta` has 2,536 rows. Fields are `model`, `test` (Bonus, Punishment, Detection, Policy), `pair_id`, `treat` (0 control, 1 treatment), `period` (1 pre, 2 post), and `violation_score` (the agent-period targeting coefficient in percentage points).

The script computes `(treatment_post − treatment_pre) − (control_post − control_pre)` for each pair, then estimates its mean and 95% t interval within model and policy. Individual targeting regressions precede this panel. The figure displays the sign-reversed DID: positive values indicate reductions. `abs_did` stores this sign reversal. The PDF, PNG, EPS and logs are saved under `outputs/plot_results/fig3a/`.

## New experiments

Configure API access, then run each shock for a model into one model-specific directory:

```sh
python experiments/rct_policy_shocks.py --model EXACT_MODEL_ID --shock bonus --pairs 30 --users-per-stage 100 --output-dir outputs/rct/model_01
python experiments/rct_policy_shocks.py --model EXACT_MODEL_ID --shock penalty --pairs 30 --users-per-stage 100 --output-dir outputs/rct/model_01
python experiments/rct_policy_shocks.py --model EXACT_MODEL_ID --shock detection --pairs 30 --users-per-stage 100 --output-dir outputs/rct/model_01
python experiments/rct_policy_shocks.py --model EXACT_MODEL_ID --shock policy --pairs 30 --users-per-stage 100 --output-dir outputs/rct/model_01
```

Enter each model's identifier, `run_dir` and plotting `pos` in `code/runs.csv`. Positions are 1 GPT, 2 Qwen, 3 DeepSeek, 4 Gemini, 5 Claude and 6 Llama.

```stata
do plot_results/fig3a/code/estimate.do "plot_results/fig3a/code/runs.csv"
do plot_results/fig3a/code/plot.do "plot_results/fig3a/data/rep_demo_fig3a.dta"
```

The estimator reads the pair's shared pre file and its treatment/control post files. For each agent-period it regresses purchase (0 or 100) on the top-30% indicator, log income and numeric gender/race/education controls, then forms the paired DID. New-output selection follows descending score and ascending name. Original sample rules are retained; stage estimates and included pairs are recorded in the output directory. The fitted plotting data are saved as `data/rep_demo_fig3a.dta`.
