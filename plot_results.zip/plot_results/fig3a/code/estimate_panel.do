* Figure 3a: archived agent-period panel -> paired DID -> plotting data.
* Run from the replication package root. No model calls or random draws.
version 17.0
clear all
set more off
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3a"
capture log close fig3a_panel
log using "outputs/plot_results/fig3a/estimate_panel.log", text replace name(fig3a_panel)

* 1. The supplied outcome is the original first-stage violation score.
use "plot_results/fig3a/data/fig3a_analysis_panel.dta", clear
isid model test pair_id treat period
assert inlist(treat,0,1) & inlist(period,1,2)
assert !missing(violation_score)
by model test pair_id, sort: assert _N==4

* 2. Within each pair, difference treatment and control changes.
reshape wide violation_score, i(model test pair_id treat) j(period)
gen change=violation_score2-violation_score1
keep model test pair_id treat change
reshape wide change, i(model test pair_id) j(treat)
gen delta=change1-change0
export delimited using "outputs/plot_results/fig3a/panel_pair_effects.csv", replace
tempfile pairs estimates
save `pairs'
levelsof model, local(models)
tempname results
postfile `results' str40 model str12 test double did cilb ciub using `estimates', replace

* 3. Original intercept-only paired-difference regression and 95% t interval.
foreach model of local models {
    foreach test in Bonus Punishment Detection Policy {
        use `pairs', clear
        keep if model=="`model'" & test=="`test'"
        reg delta
        matrix T=r(table)
        post `results' ("`model'") ("`test'") (T[1,1]) (T[5,1]) (T[6,1])
    }
}
postclose `results'

* 4. Positive plotted effects indicate a reduction: use -DID, not abs(DID).
use `estimates', clear
gen abs_did=-did
gen ci_lower=-ciub
gen ci_upper=-cilb
gen byte pos=.
replace pos=1 if model=="gpt-4o"
replace pos=2 if model=="qwen-turbo"
replace pos=3 if model=="deepseek-r1-671b"
replace pos=4 if model=="gemini-2.0-flash-001"
replace pos=5 if model=="claude-3.5-haiku"
replace pos=6 if model=="llama-3.1-70b-instruct"
assert !missing(pos)
isid test pos
sort test pos
save "plot_results/fig3a/data/rep_demo_fig3a.dta", replace
log close fig3a_panel
