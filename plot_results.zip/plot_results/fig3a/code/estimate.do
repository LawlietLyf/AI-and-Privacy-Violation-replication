* Estimate Fig. 3a from new rct_policy_shocks.py outputs.
* Run from the replication root: do plot_results/fig3a/code/estimate.do "plot_results/fig3a/code/runs.csv"
version 17.0
clear all
set more off
args run_map
if `"`run_map'"' == "" {
    display as error "Usage: do plot_results/fig3a/code/estimate.do plot_results/fig3a/code/runs.csv"
    exit 198
}

capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3a"
local out "outputs/plot_results/fig3a"
capture log close fig3a_estimate
log using "`out'/estimate.log", text replace name(fig3a_estimate)

* Each row identifies one model, its four-shock output directory and plot position.
import delimited using `"`run_map'"', varnames(1) stringcols(_all) clear
confirm variable model run_dir pos
assert model != "" & run_dir != ""
destring pos, replace
assert inrange(pos, 1, 6) & pos == floor(pos)
isid model
isid pos
local models = _N
if `models' == 0 {
    display as error "The run map is empty."
    exit 2000
}
forvalues m = 1/`models' {
    local model`m' = model[`m']
    local run`m' = run_dir[`m']
    local pos`m' = pos[`m']
}

* Keep the original per-agent encoding across pre and post observations.
* Scores are already parsed by the Python experiment; purchase is its saved outcome.
program define fig3a_branch, rclass
    syntax, PRE(string) POST(string)
    tempfile pre_data post_data
    foreach stage in pre post {
        local status_`stage' "ok"
        local n_input_`stage' = .
        local n_valid_`stage' = .
        local n_invalid_purchase_`stage' = .
        local n_used_`stage' = .
        local beta_`stage' = .
        local file `"``stage''"'
        capture confirm file `"`file'"'
        if _rc local status_`stage' "missing_file"
        if "`status_`stage''" == "ok" {
            capture import delimited using `"`file'"', varnames(1) stringcols(_all) bindquotes(strict) clear
            if _rc local status_`stage' "unreadable_csv"
        }
        if "`status_`stage''" == "ok" {
            local n_input_`stage' = _N
            capture confirm variable score purchase income gender race highest_degree name
            if _rc local status_`stage' "missing_columns"
        }
        if "`status_`stage''" == "ok" {
            keep score purchase income gender race highest_degree name
            destring score income, replace force
            * RCT outputs save Boolean purchases; baseline-compatible CSVs may use 0/1.
            gen double purchase_value = real(strtrim(purchase))
            replace purchase_value = 1 if lower(strtrim(purchase)) == "true"
            replace purchase_value = 0 if lower(strtrim(purchase)) == "false"
            replace purchase_value = . if !inlist(purchase_value, 0, 1)
            drop purchase
            rename purchase_value purchase
            drop if missing(score) | !inrange(score, 0, 100)
            local n_valid_`stage' = _N
            quietly count if missing(purchase)
            local n_invalid_purchase_`stage' = r(N)
            gen byte period = ("`stage'" == "post")
            if "`stage'" == "pre" save "`pre_data'", replace
            else save "`post_data'", replace
        }
    }

    if "`status_pre'" == "ok" & "`status_post'" == "ok" {
        * Original RCT script excludes an agent with fewer than 50 valid post scores.
        if `n_valid_post' < 50 {
            local status_pre "post_below_50"
            local status_post "post_below_50"
        }
        else {
            use "`pre_data'", clear
            append using "`post_data'"
            encode gender, gen(igender)
            encode race, gen(iethnicity)
            encode highest_degree, gen(idegree)
            gen double Lnincome = log(income)
            gen double ibuy = 100 * purchase
            replace ibuy = . if !inlist(purchase, 0, 1)
            gsort period -score name
            by period: gen byte cut = _n <= 0.3 * _N
            foreach stage in pre post {
                local period = ("`stage'" == "post")
                capture quietly regress ibuy cut Lnincome igender iethnicity idegree if period == `period'
                if _rc local status_`stage' "regression_failed"
                else {
                    local n_used_`stage' = e(N)
                    if e(df_r) <= 0 local status_`stage' "no_residual_df"
                    else {
                        tempname b omitted
                        matrix `b' = e(b)
                        _ms_omit_info `b'
                        matrix `omitted' = r(omit)
                        local target_col = colnumb(`b', "cut")
                        if missing(`target_col') local status_`stage' "target_omitted"
                        else if `omitted'[1, `target_col'] local status_`stage' "target_omitted"
                        else local beta_`stage' = _b[cut]
                    }
                }
            }
        }
    }
    else {
        if "`status_pre'" == "ok" local status_pre "companion_invalid"
        if "`status_post'" == "ok" local status_post "companion_invalid"
    }
    foreach stage in pre post {
        return scalar beta_`stage' = `beta_`stage''
        return scalar n_input_`stage' = `n_input_`stage''
        return scalar n_valid_`stage' = `n_valid_`stage''
        return scalar n_invalid_purchase_`stage' = `n_invalid_purchase_`stage''
        return scalar n_used_`stage' = `n_used_`stage''
        return local status_`stage' "`status_`stage''"
    }
end

tempname stages pairs summaries
tempfile stage_data pair_data summary_data
postfile `stages' str244 model str12 test str40 pair str10 branch str4 stage ///
    double n_input n_valid_score n_invalid_purchase n_used beta str32 status using "`stage_data'", replace
postfile `pairs' str244 model str12 test str40 pair double control_pre control_post ///
    treatment_pre treatment_post delta str32 status using "`pair_data'", replace

forvalues m = 1/`models' {
    local model "`model`m''"
    local run `"`run`m''"'
    foreach shock in bonus penalty detection policy {
        if "`shock'" == "bonus" local test "Bonus"
        if "`shock'" == "penalty" local test "Punishment"
        if "`shock'" == "detection" local test "Detection"
        if "`shock'" == "policy" local test "Policy"
        local folder `"`run'/`shock'"'
        local files ""
        capture local files : dir `"`folder'"' files "pair_*.csv"
        local pair_ids ""
        foreach file of local files {
            if regexm("`file'", "^pair_([0-9]+)_(pre|control_post|treatment_post)[.]csv$") {
                local pair_ids "`pair_ids' `=regexs(1)'"
            }
        }
        local pair_ids : list uniq pair_ids
        display as text "Model: `model'; shock: `shock'; input: `folder'"
        if "`pair_ids'" == "" display as error "No pair CSV files found; this cell will have missing estimates."
        foreach pair of local pair_ids {
            foreach branch in control treatment {
                quietly fig3a_branch, pre(`"`folder'/pair_`pair'_pre.csv"') ///
                    post(`"`folder'/pair_`pair'_`branch'_post.csv"')
                foreach stage in pre post {
                    local b_`branch'_`stage' = r(beta_`stage')
                    local input_`stage' = r(n_input_`stage')
                    local valid_`stage' = r(n_valid_`stage')
                    local invalid_purchase_`stage' = r(n_invalid_purchase_`stage')
                    local used_`stage' = r(n_used_`stage')
                    local status_`branch'_`stage' "`r(status_`stage')'"
                }
                foreach stage in pre post {
                    post `stages' ("`model'") ("`test'") ("`pair'") ("`branch'") ("`stage'") ///
                        (`input_`stage'') (`valid_`stage'') (`invalid_purchase_`stage'') (`used_`stage'') ///
                        (`b_`branch'_`stage'') ("`status_`branch'_`stage''")
                }
            }
            local delta = .
            local status "incomplete_stage"
            if "`status_control_pre'" == "ok" & "`status_control_post'" == "ok" & ///
               "`status_treatment_pre'" == "ok" & "`status_treatment_post'" == "ok" {
                local delta = (`b_treatment_post' - `b_treatment_pre') - (`b_control_post' - `b_control_pre')
                local status "ok"
            }
            post `pairs' ("`model'") ("`test'") ("`pair'") (`b_control_pre') (`b_control_post') ///
                (`b_treatment_pre') (`b_treatment_post') (`delta') ("`status'")
        }
    }
}
postclose `stages'
postclose `pairs'
use "`stage_data'", clear
export delimited using "`out'/stage_estimates.csv", replace
use "`pair_data'", clear
export delimited using "`out'/pair_effects.csv", replace

* The intercept is the mean matched-pair DID; the CI uses the original t interval.
postfile `summaries' str244 model str12 test byte pos double did ci_did_low ci_did_high ///
    int n_pairs_input n_pairs_valid str32 status using "`summary_data'", replace
forvalues m = 1/`models' {
    local model "`model`m''"
    foreach test in Bonus Punishment Detection Policy {
        quietly count if model == "`model'" & test == "`test'"
        local n_input = r(N)
        quietly count if model == "`model'" & test == "`test'" & !missing(delta)
        local n_valid = r(N)
        local did = .
        local low = .
        local high = .
        local status "fewer_than_two_valid_pairs"
        if `n_valid' >= 2 {
            quietly regress delta if model == "`model'" & test == "`test'"
            matrix result = r(table)
            local did = result[1,1]
            local low = result[5,1]
            local high = result[6,1]
            local status "ok"
        }
        display as text "`model' / `test': `n_valid' of `n_input' pairs retained; `status'"
        post `summaries' ("`model'") ("`test'") (`pos`m'') (`did') (`low') (`high') ///
            (`n_input') (`n_valid') ("`status'")
    }
}
postclose `summaries'
use "`summary_data'", clear
* The original figure reverses the DID sign: positive bars indicate reductions.
* Its legacy variable name abs_did does not mean an absolute value.
gen double abs_did = -did
gen double ci_lower = -ci_did_high
gen double ci_upper = -ci_did_low
drop ci_did_low ci_did_high
order model test pos did abs_did ci_lower ci_upper n_pairs_input n_pairs_valid status
sort pos test
export delimited using "`out'/rep_demo_fig3a.csv", replace
quietly count if status != "ok"
if r(N) > 0 display as error "Some cells have no estimate. Inspect stage_estimates.csv, pair_effects.csv and rep_demo_fig3a.csv."
keep model test pos did abs_did ci_lower ci_upper
save "plot_results/fig3a/data/rep_demo_fig3a.dta", replace
display as result "Saved plot_results/fig3a/data/rep_demo_fig3a.dta; paper data are unchanged."
log close fig3a_estimate
