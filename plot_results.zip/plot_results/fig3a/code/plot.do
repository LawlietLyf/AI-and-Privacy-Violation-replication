* Run from the replication root. The default redraws the supplied paper data.
version 17.0
clear all
set more off
args input
if `"`input'"' == "" {
    local input "plot_results/fig3a/data/fig3a_data.dta"
    local stem "fig3a"
}
else local stem "rep_demo_fig3a"

capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig3a"
local out "outputs/plot_results/fig3a"
capture log close fig3a_plot
log using "`out'/`stem'_plot.log", text replace name(fig3a_plot)
use `"`input'"', clear
confirm variable model test abs_did ci_lower ci_upper pos
assert inlist(test, "Bonus", "Punishment", "Detection", "Policy")
assert inrange(pos, 1, 6) & pos == floor(pos)
isid test pos
count if !missing(abs_did, ci_lower, ci_upper)
if r(N) == 0 {
    display as error "No estimable effects in the plotting input."
    log close fig3a_plot
    exit 2000
}
export delimited using "`out'/`stem'_plot_data.csv", replace

* Original Manual Construct colours, labels and graph commands.
local color_gpt "55 126 184"      
local color_qwen "77 175 74"      
local color_deepseek "255 224 0"  
local color_gemini "255 127 0"    
local color_claude "152 78 163"   
local color_llama "228 26 28"     

set scheme s1color

twoway ///
    (bar abs_did pos if test == "Bonus" & pos == 1, ///
        barwidth(0.7) color("`color_gpt'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Bonus" & pos == 2, ///
        barwidth(0.7) color("`color_qwen'") lcolor(gs8) lwidth(0.3)) ///
	(bar abs_did pos if test == "Bonus" & pos == 3, ///
        barwidth(0.7) color("`color_deepseek'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Bonus" & pos == 4, ///
        barwidth(0.7) color("`color_gemini'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Bonus" & pos == 5, ///
        barwidth(0.7) color("`color_claude'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Bonus" & pos == 6, ///
        barwidth(0.7) color("`color_llama'") lcolor(gs8) lwidth(0.3)) ///
    (rcap ci_lower ci_upper pos if test == "Bonus", ///
        lwidth(medium) lcolor(black%75) lpattern(dash)), ///
    xlabel(1 "GPT" 2 "Qwen" 3 "DS" 4 "Gemini" 5 "Claude" 6 "Llama", ///
        labsize(2.3) noticks angle(0)) ///
    xtitle("") ///
    ytitle("Treatment Effect", size(2.8) margin(small)) ///
    ylabel(0(5)35, labsize(2.5) angle(0) format(%3.0f) nogrid) ///
    title("{bf:Bonus Reduction}", size(3.2) pos(11) justification(left)) ///
    graphregion(color(white) margin(small)) ///
    plotregion(color(white) margin(small)) ///
    legend(off) ///
    name(bonus, replace) ///
    scale(1.2)

twoway ///
    (bar abs_did pos if test == "Punishment" & pos == 1, ///
        barwidth(0.7) color("`color_gpt'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Punishment" & pos == 2, ///
        barwidth(0.7) color("`color_qwen'") lcolor(gs8) lwidth(0.3)) ///
		(bar abs_did pos if test == "Punishment" & pos == 3, ///
        barwidth(0.7) color("`color_deepseek'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Punishment" & pos == 4, ///
        barwidth(0.7) color("`color_gemini'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Punishment" & pos == 5, ///
        barwidth(0.7) color("`color_claude'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Punishment" & pos == 6, ///
        barwidth(0.7) color("`color_llama'") lcolor(gs8) lwidth(0.3)) ///
    (rcap ci_lower ci_upper pos if test == "Punishment", ///
        lwidth(medium) lcolor(black%75) lpattern(dash)), ///
    xlabel(1 "GPT" 2 "Qwen" 3 "DS" 4 "Gemini" 5 "Claude" 6 "Llama", ///
        labsize(2.3) noticks angle(0)) ///
    xtitle("") ///
    ytitle("Treatment Effect", size(2.8) margin(small)) ///
    ylabel(0(5)35, labsize(2.5) angle(0) format(%3.0f) nogrid) ///
    title("{bf:Punishment Increase}", size(3.2) pos(11) justification(left)) ///
    graphregion(color(white) margin(small)) ///
    plotregion(color(white) margin(small)) ///
    legend(off) ///
    name(punishment, replace) ///
    scale(1.2)

twoway ///
    (bar abs_did pos if test == "Detection" & pos == 1, ///
        barwidth(0.7) color("`color_gpt'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Detection" & pos == 2, ///
        barwidth(0.7) color("`color_qwen'") lcolor(gs8) lwidth(0.3)) ///
	(bar abs_did pos if test == "Detection" & pos == 4, ///
        barwidth(0.7) color("`color_gemini'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Detection" & pos == 3, ///
        barwidth(0.7) color("`color_deepseek'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Detection" & pos == 5, ///
        barwidth(0.7) color("`color_claude'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Detection" & pos == 6, ///
        barwidth(0.7) color("`color_llama'") lcolor(gs8) lwidth(0.3)) ///
    (rcap ci_lower ci_upper pos if test == "Detection", ///
        lwidth(medium) lcolor(black%75) lpattern(dash)), ///
    xlabel(1 "GPT" 2 "Qwen" 3 "DS" 4 "Gemini" 5 "Claude" 6 "Llama", ///
        labsize(2.3) noticks angle(0)) ///
    xtitle("") ///
    ytitle("Treatment Effect", size(2.8) margin(small)) ///
    ylabel(0(5)35, labsize(2.5) angle(0) format(%3.0f) nogrid) ///
    title("{bf:Detection Enhancement}", size(3.2) pos(11) justification(left)) ///
    graphregion(color(white) margin(small)) ///
    plotregion(color(white) margin(small)) ///
    legend(off) ///
    name(detection, replace) ///
    scale(1.2)

twoway ///
    (bar abs_did pos if test == "Policy" & pos == 1, ///
        barwidth(0.7) color("`color_gpt'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Policy" & pos == 2, ///
	        barwidth(0.7) color("`color_qwen'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Policy" & pos == 3, ///
        barwidth(0.7) color("`color_deepseek'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Policy" & pos == 4, ///
        barwidth(0.7) color("`color_gemini'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Policy" & pos == 5, ///
        barwidth(0.7) color("`color_claude'") lcolor(gs8) lwidth(0.3)) ///
    (bar abs_did pos if test == "Policy" & pos == 6, ///
        barwidth(0.7) color("`color_llama'") lcolor(gs8) lwidth(0.3)) ///
    (rcap ci_lower ci_upper pos if test == "Policy", ///
       lwidth(medium) lcolor(black%75) lpattern(dash)), ///
    xlabel(1 "GPT" 2 "Qwen" 3 "DS" 4 "Gemini" 5 "Claude" 6 "Llama", ///
        labsize(2.3) noticks angle(0)) ///
    xtitle("") ///
    ytitle("Treatment Effect", size(2.8) margin(small)) ///
    ylabel(0(5)35, labsize(2.5) angle(0) format(%3.0f) nogrid) ///
    title("{bf:Policy Strictness}", size(3.2) pos(11) justification(left)) ///
    graphregion(color(white) margin(small)) ///
    plotregion(color(white) margin(small)) ///
    legend(off) ///
    name(policy, replace) ///
    scale(1.2)

graph combine bonus punishment detection policy, ///
    cols(2) rows(2) ///
    imargin(small) ///
    graphregion(color(white) margin(medium)) ///
    title("", size(large))
	

graph export "`out'/`stem'.png", replace width(3600) height(3000)
graph export "`out'/`stem'.eps", replace
graph export "`out'/`stem'.pdf", replace
display as result "Saved `out'/`stem'.pdf, .png and .eps"
log close fig3a_plot
