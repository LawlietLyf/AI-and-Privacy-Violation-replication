# Extended Data Figure 3: reviewed scores

Run from the package root in Stata 17+, with `grstyle` installed.

```stata
do plot_results/ed3/code/plot.do
```

`data/ed3_data.dta` contains the supplied baseline and reviewed-score estimates. The 34 records with `group_pos` form the figure. `violation_score`, `cilb` and `ciub` give the coefficient and 95% confidence limits; `agent` identifies baseline (`Manager`) and reviewed (`Detector`) scores. Output: `outputs/plot_results/ed3/ed3.pdf` and `.png`.

## Estimate from the supplied panel

```stata
do plot_results/ed3/code/estimate_panel.do
do plot_results/ed3/code/plot.do "plot_results/ed3/data/rep_demo_ed3.dta"
```

`data/ed3_analysis_panel.dta` contains 32,636 individual-model observations with the following fields:

| Field | Meaning |
|---|---|
| `model`, `obs_id` | Model and source observation number |
| `model_order` | Zero-based figure position; only positioned models are plotted |
| `score`, `new_score` | Parsed baseline and reviewed scores on the analysis scale |
| `ihistory` | Sensitive search history: 1 False; 2 True |
| `Lnincome` | Log income |
| `igender`, `iethnicity` | 1 female/2 male; 1 black/2 white |
| `idegree` | 1 bachelor; 2 doctor; 3 high school; 4 master |
| `istate` | State code, with Stata value labels |

The model identifiers include `gpt-4o` and `deepseek-r1-671b`, corresponding to GPT-4o and DeepSeek R1 671B in the paper. Each baseline/reviewed score is regressed on sensitive history, log income and the original numeric demographic controls, with state fixed effects absorbed by `areg`. The script retains conventional OLS confidence intervals.

Estimates are saved as `data/rep_demo_ed3.dta`. Their PDF/PNG figures and estimation log are written under `outputs/plot_results/ed3/`. This entry starts from the supplied final regression inputs.
