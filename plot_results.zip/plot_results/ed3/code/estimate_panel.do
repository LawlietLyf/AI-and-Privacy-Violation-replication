* ED3: final individual-level panel -> sensitive-history coefficients.
* areg provides the original absorbed-state OLS in Stata 17 and later.
version 17.0
clear all
set more off
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/ed3"
capture log close ed3_panel
log using "outputs/plot_results/ed3/estimate_panel.log", text replace name(ed3_panel)

use "plot_results/ed3/data/ed3_analysis_panel.dta", clear
isid model obs_id
assert inlist(ihistory,1,2)
assert !missing(score,Lnincome,igender,iethnicity,idegree,istate)
tempfile panel estimates
save `panel'
levelsof model, local(models)
tempname results
postfile `results' str64 model str8 agent double violation_score cilb ciub group_pos using `estimates', replace

foreach model of local models {
    use `panel', clear
    keep if model=="`model'"
    local pos=2*model_order[1]
    foreach outcome in score new_score {
        * Original numeric controls; state fixed effects are absorbed.
        areg `outcome' ihistory Lnincome igender iethnicity idegree, absorb(istate)
        matrix T=r(table)
        local agent "Detector"
        local plot_pos=`pos'
        if "`outcome'"=="score" {
            local agent "Manager"
            local plot_pos=`pos'+1
        }
        post `results' ("`model'") ("`agent'") (T[1,1]) (T[5,1]) (T[6,1]) (`plot_pos')
    }
}
postclose `results'
use `estimates', clear
sort group_pos agent
save "plot_results/ed3/data/rep_demo_ed3.dta", replace
log close ed3_panel
