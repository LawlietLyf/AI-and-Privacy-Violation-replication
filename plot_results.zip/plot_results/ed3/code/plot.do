* Extended Data Figure 3. Run from the replication package root.
* Default: supplied paper estimates. Optional argument: re-estimated plot data.
version 17.0
clear all
set more off
args input
if `"`input'"' == "" {
    local input "plot_results/ed3/data/ed3_data.dta"
    local stem "ed3"
}
else local stem "rep_demo_ed3"
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/ed3"
capture log close ed3plot
log using "outputs/plot_results/ed3/`stem'_plot.log", text replace name(ed3plot)
use `"`input'"', clear

set scheme s1color
grstyle init
grstyle color background white
grstyle color major_grid gs8
grstyle linewidth major_grid thin
grstyle linepattern major_grid dot
grstyle yesno draw_major_hgrid yes
grstyle yesno grid_draw_min yes
grstyle yesno grid_draw_max yes
grstyle anglestyle vertical_tick horizontal
grstyle gsize axis_title_gap tiny			
twoway 	(bar violation_score group_pos if agent=="Manager", ///
        horizontal barwidth(0.5) base(0) color(red%50)) ///
		(bar violation_score group_pos if agent == "Detector", ///
	horizontal barwidth(0.5) base(0) color(red%20)) ///
		(rcap ciub cilb group_pos, ///
         horizontal lwidth(medium) lcolor(black%75) lpattern(dash)), ///
    ylabel( ///
	0.8  "GPT-3.5" ///
    2.8  "GPT-4o" ///
	4.8  "GPT-5" ///
	6.8  "Qwen Turbo" ///
    8.8  "Qwen Plus" ///
	10.8  "DeepSeek 1.5B" ///
	12.8  "DeepSeek 7B" ///
    14.8  "DeepSeek 14B" ///
	16.8  "DeepSeek 32B" ///
    18.8 "DeepSeek 671B" ///
    20.8 "Llama 3.1" ///
    22.8 "Llama 4" ///
    24.8 "Claude-3.5" ///
    26.8 "Claude-4.6" ///
    28.8 "Gemini-1.5" ///
	30.8 "Gemini-2.0" ///
    32.8 "Gemini-3.0", valuelabel angle(0) labsize(*0.8) noticks ///
        grid glcolor(gs14) glwidth(vthin) glpattern(dot)) ///
    ytitle("Coefficient", size(*1.0)) ///
    xtitle("", size(*1.0)) ///
    xlabel(0(20)80, grid glcolor(gs14) glwidth(vthin) glpattern(dot)) ///
    plotregion(lstyle(none)) ///
	ytitle("") ///
	xsize(10) ysize(6) ///
	legend(order(1 "Baseline" 2 "Reviewed Score"))

graph export "outputs/plot_results/ed3/`stem'.pdf", replace
graph export "outputs/plot_results/ed3/`stem'.png", width(3600) replace
log close ed3plot
