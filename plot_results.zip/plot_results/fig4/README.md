# Figure 4: empirical analyses

Run from the package root in **Stata 17+ SE/MP**:

```stata
do plot_results/fig4/code/run.do
```

The command runs the three supplied analysis scripts and exports `fig4a`, `fig4b` and `fig4c` as PDF, PNG and editable GPH files under `outputs/plot_results/fig4/`. Regression output and sample sizes are recorded in `fig4_run.log`.

## Installation

Install missing dependencies once, from a fresh Stata session in the package root:

```stata
ssc install grstyle
ssc install coefplot
ssc install ppmlhdfe
ssc install ivreg2
ssc install ranktest
ssc install egenmore

net install ftools, from("`c(pwd)'/plot_results/fig4/vendor/ftools-master/src") replace
net install reghdfe, from("`c(pwd)'/plot_results/fig4/vendor/reghdfe-master/src") replace
net install ivreghdfe, from("`c(pwd)'/plot_results/fig4/vendor/ivreghdfe-master/src") replace
```

The three local installs use the supplied dependency versions and licence files. The analysis was checked with Stata 18 MP, grstyle 1.1.1, coefplot 1.8.6, ppmlhdfe 2.3.0, ftools 2.49.1, reghdfe 6.12.5, ivreghdfe 1.1.3, ivreg2 4.1.12, ranktest 2.0.04 and egenmore `_gxtile` 2.1. The scripts use `set matsize 3000`, hence the SE/MP requirement. Use writable package and Stata PERSONAL directories.

## Analyses and data

| Panel | Script in `code/` | Analysis |
|---|---|---|
| 4a | `Baseline Regressions -- Nature Submission.do` | Long-difference Poisson, instrumental-variable, panel Poisson and GDPR models |
| 4b | `Heterogenity Analyses -- Nature Submission.do` | Ownership, prior incidents, competition and analyst coverage |
| 4c | `Incident-Level Analyses -- Nature Submission.do` | Mean and median privacy costs by AI intensity |

The 19 supplied DTA files are in `data/`. The scripts preserve the authors' sample restrictions, merges, controls, fixed effects, standard errors and graph commands. Run the wrapper above to estimate and export all three panels; each original do-file can also be run separately.

GVKEY values have been replaced with randomized identifiers. Use the supplied tables together for their internal merges; these identifiers are not external Compustat keys. Data access and reuse follow the manuscript's Data Availability statement and applicable source terms.

The exported GPH files allow the final Graph Editor formatting used in the manuscript to be applied to the generated graphs. Rerunning replaces the generated output files.
