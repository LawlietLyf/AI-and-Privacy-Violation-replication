* Figure 4a-c: run the supplied analyses and export their base graphs.
* Run from the replication package root. No model API is called.
version 17.0
clear all
set more off
foreach command in grstyle ppmlhdfe coefplot ftools reghdfe ivreghdfe ivreg2 ranktest _gxtile {
    capture which `command'
    if _rc {
        display as error "Missing command: `command'. Follow plot_results/fig4/README.md."
        exit 499
    }
}
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig4"
capture log close fig4run
log using "outputs/plot_results/fig4/fig4_run.log", text replace name(fig4run)
display "Started: `c(current_date)' `c(current_time)'"
foreach command in grstyle ppmlhdfe coefplot ftools reghdfe ivreghdfe ivreg2 ranktest _gxtile {
    which `command'
}

do "plot_results/fig4/code/Baseline Regressions -- Nature Submission.do"
graph save "outputs/plot_results/fig4/fig4a.gph", replace
graph export "outputs/plot_results/fig4/fig4a.pdf", replace
graph export "outputs/plot_results/fig4/fig4a.png", width(2400) replace

do "plot_results/fig4/code/Heterogenity Analyses -- Nature Submission.do"
graph save "outputs/plot_results/fig4/fig4b.gph", replace
graph export "outputs/plot_results/fig4/fig4b.pdf", replace
graph export "outputs/plot_results/fig4/fig4b.png", width(2400) replace

do "plot_results/fig4/code/Incident-Level Analyses -- Nature Submission.do"
graph save "outputs/plot_results/fig4/fig4c.gph", replace
graph export "outputs/plot_results/fig4/fig4c.pdf", replace
graph export "outputs/plot_results/fig4/fig4c.png", width(2400) replace
display "Completed Figure 4a-c: `c(current_date)' `c(current_time)'"
log close fig4run
