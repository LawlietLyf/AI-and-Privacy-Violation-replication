* Figure 2b: baseline experiment CSVs -> estimates -> plotting DTA.
* Run from the replication package root. Paths in runs.csv are relative to that root.
* Source specification: original reg_privacy_accuracy(all models).do, top-30% branch.
version 17.0
clear all
set more off
args runs_csv
if `"`runs_csv'"' == "" local runs_csv "plot_results/fig2/code/runs.csv"
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig2"
capture log close fig2estimate
log using "outputs/plot_results/fig2/estimate.log", text replace name(fig2estimate)

import delimited using `"`runs_csv'"', varnames(1) stringcols(_all) clear
count
if r(N)==0 {
    display as error "Fill runs.csv with input CSV paths and explicit display labels."
    exit 2000
}
assert model_label!=""
assert collection_csv!="" | processing_csv!="" | dissemination_csv!=""
destring group_pos category, replace
assert group_pos==floor(group_pos) & inrange(group_pos,1,33)
assert category==floor(category) & inrange(category,1,6)
isid group_pos
local n_models = _N
tempfile runs estimates
save `runs'
tempname results
postfile `results' str24 privacy_test double violation_score cilb ciub ///
    group_pos category panel using `estimates', replace

forvalues m=1/`n_models' {
    use `runs', clear
    local display_label = model_label[`m']
    local pos = group_pos[`m']
    local family = category[`m']
    local collection = collection_csv[`m']
    local processing = processing_csv[`m']
    local dissemination = dissemination_csv[`m']
    display as text _newline "Model label: `display_label'"

    * Collection and dissemination use the experiment script's per-user 0/1 flag.
    foreach task in collection dissemination {
        local input_csv = "``task''"
        if `"`input_csv'"' != "" {
            import delimited using `"`input_csv'"', varnames(1) clear
            local planned_n = _N
            capture confirm string variable violation
            if !_rc destring violation, replace force
            capture confirm variable error
            if !_rc {
                capture confirm string variable error
                if !_rc replace violation=. if error!=""
            }
            assert inlist(violation,0,1) | missing(violation)
            count if missing(violation)
            display as text "`task': total rows=`planned_n'; excluded failed/missing rows=" r(N)
            quietly summarize violation
            if r(N)==0 {
                display as error "No valid 0/1 violation observations in `task'."
                exit 2000
            }
            local estimate = 100*r(mean)
            local se = 100*sqrt(r(mean)*(1-r(mean))/r(N))
            local lower = `estimate'-invnormal(.975)*`se'
            local upper = `estimate'+invnormal(.975)*`se'
            if "`task'"=="collection" {
                post `results' ("Data Collection") (`estimate') (`lower') (`upper') ///
                    (`pos') (`family') (1)
            }
            else {
                post `results' ("Data Dissemination") (`estimate') (`lower') (`upper') ///
                    (`pos') (`family') (3)
            }
        }
    }

    if `"`processing'"' != "" {
        import delimited using `"`processing'"', varnames(1) clear
        local planned_n = _N
        local targeted_n = floor(.30*`planned_n')
        capture confirm string variable score
        if !_rc destring score, replace force
        replace score=. if !inrange(score,0,100)
        drop if missing(score)
        count
        display as text "processing: total rows=`planned_n'; valid scores=" r(N) ///
            "; rank threshold=`targeted_n'"
        if `targeted_n'<1 | r(N)==0 exit 2000
        assert inlist(purchase,0,1)
        assert income>0 & !missing(income)
        encode gender, gen(igender)
        encode race, gen(iethnicity)
        encode highest_degree, gen(idegree)
        gen Lnincome=log(income)
        gen ibuy=100*purchase
        egen rank=rank(score), field
        gen cut=rank<=`targeted_n'
        * Same numeric-encoded controls and conventional OLS standard errors as source.
        reg ibuy cut Lnincome igender iethnicity idegree
        display as text "processing: regression observations=" e(N)
        if e(df_r)<=0 | _se[cut]==0 {
            display as error "Insufficient variation to estimate the processing targeting coefficient."
            exit 2001
        }
        matrix R=r(table)
        post `results' ("Data Processing") (R[1,1]) (R[5,1]) (R[6,1]) ///
            (`pos') (`family') (2)
    }
}
postclose `results'

use `estimates', clear
merge m:1 group_pos using `runs', keepusing(model_label)
tabulate _merge
assert _merge==3
drop _merge
forvalues i=1/`=_N' {
    local pos = group_pos[`i']
    local display_label = model_label[`i']
    label define poslbl `pos' `"`display_label'"', modify
}
label values group_pos poslbl
label define panellbl 1 "Collection" 2 "Processing" 3 "Dissemination"
label values panel panellbl
keep privacy_test violation_score cilb ciub group_pos category panel
sort panel group_pos
save "plot_results/fig2/data/rep_demo_fig2.dta", replace
export delimited using "outputs/plot_results/fig2/rep_demo_fig2.csv", replace
log close fig2estimate
