* Figure 2b. Run from the replication package root.
* Default: supplied paper plotting data; optional argument: a newly estimated DTA.
version 17.0
clear all
set more off
args input_dta
local output_name "rep_demo_fig2"
if `"`input_dta'"' == "" {
    local input_dta "plot_results/fig2/data/fig2_data.dta"
    local output_name "fig2"
}
use `"`input_dta'"', clear
levelsof group_pos, local(model_positions)
capture mkdir "outputs"
capture mkdir "outputs/plot_results"
capture mkdir "outputs/plot_results/fig2"
capture log close fig2plot
log using "outputs/plot_results/fig2/`output_name'_plot.log", text replace name(fig2plot)

* Start Plotting the Figure				  
grstyle init
grstyle color background white
grstyle color major_grid gs8
grstyle linewidth major_grid thin
grstyle linepattern major_grid dot
grstyle yesno draw_major_hgrid yes
grstyle yesno grid_draw_min yes
grstyle yesno grid_draw_max yes
grstyle anglestyle vertical_tick horizontal
grstyle gsize axis_title_gap tiny
 
twoway (bar violation_score group_pos if category==1, horizontal barwidth(1.5) color("55 126 184")) ///
(bar violation_score group_pos if category==2, horizontal barwidth(1.5) color("77 175 74")) ///
(bar violation_score group_pos if category==3, horizontal barwidth(1.5) color("255 224 0") ) ///
(bar violation_score group_pos if category==4, horizontal barwidth(1.5) color("228 26 28")) ///
(bar violation_score group_pos if category==5, horizontal barwidth(1.5) color("152 78 163")) ///
(bar violation_score group_pos if category==6, horizontal barwidth(1.5) color("255 127 0")) ///
	   (rcap cilb ciub group_pos, horizontal lwidth(medium) lcolor(black%75) lpattern(dash)), ///
       ytitle("") ///
       xlabel(0(20)110) ///
       ylabel(`model_positions', valuelabel angle(0) labsize(small) noticks) ///
       yscale(reverse noline) ///
       xtitle("Violation Score") ///
       by(panel, rows(1) note("") legend(off))  ///
       graphregion(margin(0)) plotregion(margin(0)) ///
	   legend(off)

graph export "outputs/plot_results/fig2/`output_name'.pdf", replace
graph export "outputs/plot_results/fig2/`output_name'.png", width(3600) replace
log close fig2plot
