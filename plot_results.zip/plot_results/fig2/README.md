# Figure 2b

Run from the package root in Stata 17+, with `grstyle` installed.

## Paper figure

```stata
do plot_results/fig2/code/plot.do
```

`data/fig2_data.dta` contains the point estimates and 95% confidence limits for 17 models and three tasks (51 rows). Output: `outputs/plot_results/fig2/fig2.pdf` and `.png`.

## New experiments

For each model, run the three experiments into separate directories:

```sh
python experiments/information_collection.py --model EXACT_MODEL_ID --output-dir outputs/baselines/model_01/collection
python experiments/information_processing.py --model EXACT_MODEL_ID --output-dir outputs/baselines/model_01/processing
python experiments/information_dissemination.py --model EXACT_MODEL_ID --output-dir outputs/baselines/model_01/dissemination
```

Each defaults to 2,000 profiles. Configure API access as described in the [main README](../../README.md). Enter the resulting paths in `code/runs.csv`, keeping the models and tasks you ran.

| Run-list field | Meaning |
|---|---|
| `model_label`, `group_pos`, `category` | Display label, model position and colour family |
| `collection_csv`, `processing_csv`, `dissemination_csv` | Corresponding result CSV; leave empty for an omitted task |

```stata
do plot_results/fig2/code/estimate.do
do plot_results/fig2/code/plot.do "plot_results/fig2/data/rep_demo_fig2.dta"
```

Collection and dissemination use the mean valid violation indicator, multiplied by 100, with 95% Wald intervals. Processing regresses `100 * purchase` on the top-30% indicator, log income and the original numeric encodings of gender, race and education. The indicator uses descending competition rank with a cutoff of 30% of the initial input count. Processing inputs are `score` (0–100), `purchase` (0/1), `income`, `gender`, `race` and `highest_degree`. The log records usable observations.

The estimator writes `data/rep_demo_fig2.dta`; its plot and log are under `outputs/plot_results/fig2/`. For a one-model example using the supplied sample:

```stata
do plot_results/demo/code/run_fig2_demo.do
```
